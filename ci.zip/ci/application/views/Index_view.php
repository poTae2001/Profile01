<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Thanapon Yapan</title>

        
    </head>

    <body>
        <header class="spyre-navbar navbar navbar-expand-lg bg-secondary navbar-dark fixed-top align-items-center" data-transparent data-text-color="#ffffff">
        
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo site_url('Index');?>">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Profile');?>">ประวัติส่วนตัว</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Academicwork');?>">ผลงานทางวิชาการ</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Activity');?>">กิจกรรม</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Contact');?>">ติดต่อข้อมูล</a></li>

        </li></li></ul>
    </div>
  </div>
</nav>
</header>

<div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="true">
  <div class="carousel-indicators">
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="0" class="active" aria-current="true" aria-label="Slide 1"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="1" aria-label="Slide 2"></button>
    <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="2" aria-label="Slide 3"></button>
  </div>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img src="<?php echo base_url('img');?>/TY.jpg" class="d-block w-100" alt="..." width ="500px">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url('img');?>/TY3.jpg" class="d-block w-100" alt="..." width ="500px">
    </div>
    <div class="carousel-item">
      <img src="<?php echo base_url('img');?>/TY6.jpg" class="d-block w-100" alt="..." width ="500px">
    </div>
  </div>
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>
<br><br>
<section id="section-4" class="text-center">
                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-6 mb-4 mb-lg-6" data-aos="fade-up" data-aos-duration="1000">
                            <a href="<?php echo site_url('Profile');?>" target="_blank" class="mb-3 d-block position-relative">
                                <div class="position-absolute d-flex justify-content-center align-items-center w-100 h-100 bg-secondary rounded text-white">
                                    <i class="fas fa-link fa-2x"></i>
                                </div>
                                <img src="<?php echo base_url('img');?>/TY6.jpg" alt="" class="position-relative img-fluid w-100 shadow-lg rounded opacity-1-hover" />
                            </a>
                            <h4><a href="<?php echo site_url('Profile');?>" target="_blank" class="text-body">ประวัติส่วนตัว</a></h4>
                        </div><br>
                        <div class="col-lg-6 mb-4 mb-lg-6" data-aos="fade-up" data-aos-duration="1000">
                            <a href="<?php echo site_url('Academic');?>" target="_blank" class="mb-3 d-block position-relative">
                                <div class="position-absolute d-flex justify-content-center align-items-center w-100 h-100 bg-secondary rounded text-white">
                                    <i class="fas fa-link fa-2x"></i>
                                </div>
                                <img src="<?php echo base_url('img');?>/TY.jpg" alt="" class="position-relative img-fluid w-100 shadow-lg rounded opacity-1-hover" />
                            </a>
                            <h4><a href="<?php echo site_url('Academic');?>" target="_blank" class="text-body">ผลงานทางวิชาการ</a></h4>
                        </div>
                        <div class="col-lg-6 mb-4 mb-lg-6" data-aos="fade-up" data-aos-duration="1000">
                            <a href="<?php echo site_url('Activity');?>" target="_blank" class="mb-3 d-block position-relative">
                                <div class="position-absolute d-flex justify-content-center align-items-center w-100 h-100 bg-secondary rounded text-white">
                                    <i class="fas fa-link fa-2x"></i>
                                </div>
                                <img src="<?php echo base_url('img');?>/TY1.jpg" alt="" class="position-relative img-fluid w-100 shadow-lg rounded opacity-1-hover" />
                            </a>
                            <h4><a href="<?php echo site_url('Activity');?>" target="_blank" class="text-body">กิจกรรม</a></h4>
                        </div><br>
                        <div class="col-lg-6 mb-4 mb-lg-6" data-aos="fade-up" data-aos-duration="1000">
                            <a href="<?php echo site_url('Contact');?>" target="_blank" class="mb-3 d-block position-relative">
                                <div class="position-absolute d-flex justify-content-center align-items-center w-100 h-100 bg-secondary rounded text-white">
                                    <i class="fas fa-link fa-2x"></i>
                                </div>
                                <img src="<?php echo base_url('img');?>/TY2.jpg"  alt="" class="position-relative img-fluid w-100 shadow-lg rounded opacity-1-hover" />
                            </a>
                            <h4><a href="<?php echo site_url('Contact');?>" target="_blank" class="text-body">ติดต่อข้อมูล</a></h4>
                        </div>
                        <span id="digitalclock" class="styling"></span>

<script>
<!--

var alternate=0
var standardbrowser=!document.all&&!document.getElementById

if (standardbrowser)
document.write('<form name="tick"><input type="text" name="tock" size="11"></form>')

function show(){
if (!standardbrowser)
var clockobj=document.getElementById? document.getElementById("digitalclock") : document.all.digitalclock
var Digital=new Date()
var hours=Digital.getHours()
var minutes=Digital.getMinutes()
var dn="AM"

if (hours==12) dn="PM" 
if (hours>12){
dn="PM"
hours=hours-12
}
if (hours==0) hours=12
if (hours.toString().length==1)
hours="0"+hours
if (minutes<=9)
minutes="0"+minutes

if (standardbrowser){
if (alternate==0)
document.tick.tock.value=hours+" : "+minutes+" "+dn
else
document.tick.tock.value=hours+"   "+minutes+" "+dn
}
else{
if (alternate==0)
clockobj.innerHTML=hours+"<font color='lime'> : </font>"+minutes+" "+"<sup style='font-size:1px'>"+dn+"</sup>"
else
clockobj.innerHTML=hours+"<font color='black'> : </font>"+minutes+" "+"<sup style='font-size:1px'>"+dn+"</sup>"
}
alternate=(alternate==0)? 1 : 0
setTimeout("show()",1000)
}
window.onload=show

//-->
</script><br><br><br>

                        <a href="#" style="text-align:center;width:100%;" class="btn btn-danger">กลับไปข้างบน</a>
                        
                        
</boyd>
</html>
                        
                                







