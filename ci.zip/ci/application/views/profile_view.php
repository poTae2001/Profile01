<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Thanapon Yapan</title>
        <script language="JavaScript">
<!-- Begin
alert("ห้ามคัดลอกข้อมูล")
// End -->
</script>
    </head>

    <body>
        <header class="spyre-navbar navbar navbar-expand-lg bg-secondary navbar-dark fixed-top align-items-center" data-transparent data-text-color="#ffffff">
        
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo site_url('Index');?>">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Profile');?>">ประวัติส่วนตัว</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Academicwork');?>">ผลงานทางวิชาการ</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Activity');?>">กิจกรรม</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Contact');?>">ติดต่อข้อมูล</a></li>

        </li></li></ul>
    </div>
  </div>
  </nav>
</header>
<div class="bg-success p-2 text-dark bg-opacity-50">
<br><br><br>
<nav id="navbar-example2" class="navbar bg-light px-3 mb-3">
  <a class="navbar-brand" href="#">ประวัติส่วนตัว</a>
  <ul class="nav nav-pills">
    <li class="nav-item">
      <a class="nav-link" href="#scrollspyHeading1">First</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#scrollspyHeading3">Second</a>
    </li>
      </ul>
    </li>
  </ul>
</nav>
<div style="text-align:center;width:100%;" data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" class="scrollspy-example bg-light p-3 rounded-2" tabindex="0">
<img src ="<?php echo base_url('img');?>/TY4.jpg" alt="" width ="350px"><br><br>
<h4 id="scrollspyHeading3">ประวัติโดยย่อ</h4>
  <p>ข้าพเจ้าชื่อ ธนพล นามสกุล ยะปาน ชื่อเล่น โปเต้<br>
    เชื้อชาติ ไทย สัญชาติ ไทย ศาสนา พุทธ สถานะภาพ โสด<br>
    วันเกิด วันอังคาร ที่ 9 เดือนมกราคม พ.ศ.2544 อายุ 21 ปี <br>
    ข้าพเจ้าเป็นบุตร คนที่ 2 มีพี่น้องทั้งหมด 2 คน ชาย 2 <br><br>
    ที่อยู่ปัจจุบัน<br>
    บ้านเลขที่ 11 หมู่ 7 ตำบล แม่กุ อำเภอ แม่สอด จังหวัด ตาก 63110<br><br>
    E-mail = thanpon23@gmail.com</p>
  <h4 id="scrollspyHeading2">ประวัติการศึกษา</h4>
  <p>สำเร็จการศึกษาประถมการศึกษาจาก<br>โรงเรียนเทศบาลวัดชุมพลคีรี อำเภอ แม่สอด จังหวัด ตาก<br><br>
  สำเร็จการศึกษามัธยมการศึกษาตอนต้นจาก<br>โรงเรียนเทศบาลวัดชุมพลคีรี อำเภอ แม่สอด จังหวัด ตาก<br><br>
    สำเร็จการศึกษาประถมการศึกษาตอนปลายจาก<br>โรงเรียนสรรพวิทยาคม อำเภอ แม่สอด จังหวัด ตาก<br><br>
    กำลังศึกษาระดับปริญาตรี อยู่ที่ มหาวิทยาลัยเทคโนโลยีราชมงคลล้านนา ตาก</p>
  <h4 id="scrollspyHeading3">งานอดิเรก</h4>
  <a href="https://www.youtube.com/watch?v=VaaMcW_-RPA" target="_blank"class="link-danger">link เพลง </a>
  <p>เล่นกีฬา เช่น เล่นฟุตบอล เล่นแบตมินตัน เป็นต้น<br>
ดูหนังฟังเพลง ในเวลาว่าง <br></p>
  <h4 id="scrollspyHeading4">ความชอบส่วนตัว</h4>
  <p>อาหาร  ก๋วยเตี๋ยว พะแนง เป็นต้น<br>
ขนมหวาน  เค้ก โดนัท เป็นต้น<br>
วิชาที่ชอบ ชอบทุกวิชาที่เกี่ยวกับคอมพิวเตอร์ <br>
</p>
</div>
</div>

<a href="#" style="text-align:center;width:100%;" class="btn btn-danger">กลับไปข้างบน</a>
</boyd>
</html>