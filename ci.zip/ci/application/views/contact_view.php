<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">

        <title>Thanapon Yapan</title>

    </head>

    <body>
        <header class="spyre-navbar navbar navbar-expand-lg bg-secondary navbar-dark fixed-top align-items-center" data-transparent data-text-color="#ffffff">
        
  <div class="container-fluid">
    <a class="navbar-brand" href="<?php echo site_url('Index');?>">Home</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Profile');?>">ประวัติส่วนตัว</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Academicwork');?>">ผลงานทางวิชาการ</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Activity');?>">กิจกรรม</a></li>
        <li class="nav-item">
          <a class="nav-link" href="<?php echo site_url('Contact');?>">ติดต่อข้อมูล</a></li>

        </li></li></ul>
    </div>
  </div>
</nav>
</header>
<div class="bg-success p-2 text-dark bg-opacity-50">
<br><br><br>
<nav id="navbar-example2" class="navbar bg-light px-3 mb-3">
  <a class="navbar-brand" href="#">ข้อมูลติดต่อ</a>
</div>
<div class="bg-success p-2 text-dark bg-opacity-50">
<div style="text-align:center;width:100%;" data-bs-spy="scroll" data-bs-target="#navbar-example2" data-bs-root-margin="0px 0px -40%" data-bs-smooth-scroll="true" class="scrollspy-example bg-light p-3 rounded-2" tabindex="0">
<h3 class="">ช่องทางการติดต่อ </h3><br>
<img src ="<?php echo base_url('img');?>/TY2.jpg" alt="" width ="350px"><br><br>
<footer class="footer text-center">
            <div class="container">
                <div class="row">
                    
                    <div class="text-align:center;width:100%;">
                        <a class="btn btn-outline-Drak btn-social mx-1" href="https://www.facebook.com/Thana.pon.44/"target="_blank"><i class="fab fa-fw fa-facebook-f"></i></a>
                        <a class="btn btn-outline-Drak btn-social mx-1" href="https://line.me/ti/p/cbVcAdQQnQ"target="_blank"><i class="fab fa-fw fa-line"></i></a>
                        <a class="btn btn-outline-Drak btn-social mx-1" href="https://www.instagram.com/tnpyapan_/"target="_blank"><i class="fab fa-fw fa-instagram"></i></a>
</div><br><br>
<p class="text">Facebook : <a href="https://www.facebook.com/Thana.pon.44/" target="_blank"class="link-danger">Thanapon Yapan</a></p><br>
<p class="text">IG : <a href="https://www.instagram.com/tnpyapan_/" target="_blank"class="link-danger">tnpyapan_</a></p><br>
<p class="text">Line : Rabbittae</p><br>
<p class="text">เบอร์ : 0650076877</p>
<!DOCTYPE html>
<html lang="en">
    <head>
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    </div>
                </div>
            </div>
        </footer>
    </body>
</html>

<a href="#" style="text-align:center;width:100%;" class="btn btn-danger">กลับไปข้างบน</a>

</body>
</html>

